package com.xebia.mckinsey;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MckinseyApplication {

	public static void main(String[] args) {
		SpringApplication.run(MckinseyApplication.class, args);
	}
}
